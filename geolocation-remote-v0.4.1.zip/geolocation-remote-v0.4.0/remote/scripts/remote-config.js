var remote = {};

remote.defaults = {
  distance: 1000,
  angle: 45
};

remote.pusherConfig = {
  authEndpoint: 'http://localhost:5000/pusher/auth',
  KEY: KEY
};